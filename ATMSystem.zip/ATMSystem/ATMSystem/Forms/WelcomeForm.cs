﻿using System;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ATMSystem.Forms
{
    public partial class WelcomeForm : Form
    {
        private System.Windows.Forms.Timer? timer;
        private int counter = 0;

        public WelcomeForm()
        {
            InitializeComponent();
        }

        private void WelcomeForm_Load(object sender, EventArgs e)
        {
            timer = new System.Windows.Forms.Timer();
            timer.Interval = 50; // milliseconds
            timer.Tick += Timer_Tick;
            timer!.Start();
        }

        private void Timer_Tick(object? sender, EventArgs e)
        {
            counter++;

            progressBar.Value = Math.Min(progressBar.Value + 4, 100);
            lblMessage.Text = $"Loading... {progressBar.Value}%";

            if (progressBar.Value >= 100)
            {
                timer!.Stop();
                this.Hide();
                PinEntryForm pinForm = new PinEntryForm();
                pinForm.ShowDialog();
                this.Close();
            }
        }
    }
}

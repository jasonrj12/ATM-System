﻿using System;
using System.Windows.Forms;

namespace ATMSystem
{
    public partial class DepositForm : Form
    {
        private string cardNumber;
        private string accountNumber;

        public DepositForm(string cardNumber, string accountNumber)
        {
            InitializeComponent();
            this.cardNumber = cardNumber;
            this.accountNumber = accountNumber;
        }
    }
}

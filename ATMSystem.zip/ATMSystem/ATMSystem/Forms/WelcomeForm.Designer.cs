﻿namespace ATMSystem.Forms
{
    partial class WelcomeForm
    {
        private System.ComponentModel.IContainer components = null;
        private Label lblTitle;
        private Label lblMessage;
        private ProgressBar progressBar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle = new Label();
            this.lblMessage = new Label();
            this.progressBar = new ProgressBar();
            this.SuspendLayout();

            // lblTitle
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(70, 40);
            this.lblTitle.Size = new System.Drawing.Size(400, 50);
            this.lblTitle.Text = "WELCOME TO ABC ATM";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // lblMessage
            this.lblMessage.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.lblMessage.Location = new System.Drawing.Point(170, 110);
            this.lblMessage.Size = new System.Drawing.Size(200, 30);
            this.lblMessage.Text = "Loading... 0%";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // progressBar
            this.progressBar.Location = new System.Drawing.Point(100, 150);
            this.progressBar.Size = new System.Drawing.Size(300, 25);
            this.progressBar.Minimum = 0;
            this.progressBar.Maximum = 100;

            // WelcomeForm
            this.ClientSize = new System.Drawing.Size(500, 250);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.progressBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.WelcomeForm_Load);
            this.Name = "WelcomeForm";
            this.Text = "Welcome";
            this.ResumeLayout(false);
        }
    }
}

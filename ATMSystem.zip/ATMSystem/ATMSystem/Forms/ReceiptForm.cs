﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATMSystem
{
    public partial class ReceiptForm
    {
        private void panelReceipt_Paint(object sender, PaintEventArgs e)
        {

        }
        // This class intentionally left empty as all code is in the Designer file
        // This is not the traditional approach but will work with your current structure
    }
}
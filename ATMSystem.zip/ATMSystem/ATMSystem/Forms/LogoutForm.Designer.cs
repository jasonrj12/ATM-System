﻿namespace ATMSystem.Forms
{
    partial class LogoutForm
    {
        private System.ComponentModel.IContainer components = null;
        private Label lblMessage;
        private ProgressBar progressBar;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null)
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblMessage = new Label();
            this.progressBar = new ProgressBar();

            // lblMessage
            this.lblMessage.Font = new System.Drawing.Font("Segoe UI", 14F);
            this.lblMessage.Location = new System.Drawing.Point(125, 40);
            this.lblMessage.Size = new System.Drawing.Size(250, 30);
            this.lblMessage.Text = "Logging out... 0%";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // progressBar
            this.progressBar.Location = new System.Drawing.Point(70, 90);
            this.progressBar.Size = new System.Drawing.Size(350, 25);
            this.progressBar.Minimum = 0;
            this.progressBar.Maximum = 100;

            // LogoutForm
            this.ClientSize = new System.Drawing.Size(500, 160);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.progressBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.LogoutForm_Load);
            this.Name = "LogoutForm";
            this.Text = "Logging Out";
            this.ResumeLayout(false);
        }
    }
}

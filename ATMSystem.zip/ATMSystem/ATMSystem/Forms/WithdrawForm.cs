﻿using System;
using System.Windows.Forms;

namespace ATMSystem
{
    public partial class WithdrawForm
    {
        // This class intentionally left empty as all code is in the Designer file
    }
}
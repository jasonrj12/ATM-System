﻿using System;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace ATMSystem
{
    public partial class ReceiptForm : Form
    {
        private string accountNumber;
        private string transactionType;
        private decimal amount;
        private decimal previousBalance;
        private decimal newBalance;
        private int transactionId;
        private DateTime transactionDate = DateTime.Now;

        public ReceiptForm(string accountNumber, string transactionType, decimal amount,
            decimal previousBalance, decimal newBalance, int transactionId)
        {
            InitializeComponent();
            this.accountNumber = accountNumber;
            this.transactionType = transactionType;
            this.amount = amount;
            this.previousBalance = previousBalance;
            this.newBalance = newBalance;
            this.transactionId = transactionId;

            DisplayReceipt();  // This will now populate the panel
        }

        private Label lblTitle;
        private Label lblSubtitle;
        private Panel panelReceipt;
        private Label lblReceiptTitle;
        private Label lblDateTime;
        private Label lblTransactionType;
        private Label lblAmount;
        private Label lblAccountNumber;
        private Label lblPreviousBalance;
        private Label lblNewBalance;
        private Label lblTransactionId;
        private Label lblThankYou;
        private Button btnPrint;
        private Button btnDone;

        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblSubtitle = new Label();
            panelReceipt = new Panel();
            lblReceiptTitle = new Label();
            lblDateTime = new Label();
            lblTransactionType = new Label();
            lblAmount = new Label();
            lblAccountNumber = new Label();
            lblPreviousBalance = new Label();
            lblNewBalance = new Label();
            lblTransactionId = new Label();
            lblThankYou = new Label();
            btnPrint = new Button();
            btnDone = new Button();

            // lblTitle
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblTitle.Location = new Point(137, 20);
            lblTitle.Text = "ATM SYSTEM";

            // lblSubtitle
            lblSubtitle.AutoSize = true;
            lblSubtitle.Font = new Font("Segoe UI", 12F);
            lblSubtitle.Location = new Point(179, 50);
            lblSubtitle.Text = "RECEIPT";

            // panelReceipt
            panelReceipt.BackColor = Color.White;
            panelReceipt.BorderStyle = BorderStyle.FixedSingle;
            panelReceipt.Location = new Point(50, 80);
            panelReceipt.Size = new Size(350, 300);

            // All receipt labels
            lblReceiptTitle = CreateLabel("ABC BANK ATM RECEIPT", new Point(50, 10), FontStyle.Bold);
            lblDateTime = CreateLabel("", new Point(20, 40));
            lblTransactionType = CreateLabel("", new Point(20, 65));
            lblAmount = CreateLabel("", new Point(20, 90), FontStyle.Bold);
            lblAccountNumber = CreateLabel("", new Point(20, 115));
            lblPreviousBalance = CreateLabel("", new Point(20, 140));
            lblNewBalance = CreateLabel("", new Point(20, 165), FontStyle.Bold);
            lblTransactionId = CreateLabel("", new Point(20, 190));
            lblThankYou = CreateLabel("Thank you for using our ATM", new Point(40, 230), FontStyle.Italic);

            // Add labels to panel
            panelReceipt.Controls.Add(lblReceiptTitle);
            panelReceipt.Controls.Add(lblDateTime);
            panelReceipt.Controls.Add(lblTransactionType);
            panelReceipt.Controls.Add(lblAmount);
            panelReceipt.Controls.Add(lblAccountNumber);
            panelReceipt.Controls.Add(lblPreviousBalance);
            panelReceipt.Controls.Add(lblNewBalance);
            panelReceipt.Controls.Add(lblTransactionId);
            panelReceipt.Controls.Add(lblThankYou);

            // Print Button
            btnPrint.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnPrint.Location = new Point(50, 400);
            btnPrint.Size = new Size(150, 50);
            btnPrint.Text = "Print Receipt";
            btnPrint.Click += btnPrint_Click;

            // Done Button
            btnDone.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnDone.Location = new Point(250, 400);
            btnDone.Size = new Size(150, 50);
            btnDone.Text = "Done";
            btnDone.Click += btnDone_Click;

            // ReceiptForm
            ClientSize = new Size(450, 480);
            Controls.Add(lblTitle);
            Controls.Add(lblSubtitle);
            Controls.Add(panelReceipt);
            Controls.Add(btnPrint);
            Controls.Add(btnDone);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ATM System - Receipt";
        }

        private Label CreateLabel(string text, Point location, FontStyle style = FontStyle.Regular)
        {
            return new Label
            {
                Text = text,
                Location = location,
                AutoSize = true,
                Font = new Font("Courier New", 10, style)
            };
        }

        private void DisplayReceipt()
        {
            lblDateTime.Text = "DATE/TIME: " + transactionDate.ToString("yyyy-MM-dd HH:mm:ss");
            lblTransactionType.Text = "TRANSACTION: " + transactionType;
            lblAmount.Text = "AMOUNT: $" + amount.ToString("N2");
            string maskedAccount = "XXXX" + accountNumber.Substring(Math.Max(0, accountNumber.Length - 4));
            lblAccountNumber.Text = "ACCOUNT: " + maskedAccount;
            lblPreviousBalance.Text = "PREVIOUS BALANCE: $" + previousBalance.ToString("N2");
            lblNewBalance.Text = "NEW BALANCE: $" + newBalance.ToString("N2");
            lblTransactionId.Text = "TRANSACTION ID: " + transactionId.ToString();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                PrintDocument printDocument = new PrintDocument();
                printDocument.PrintPage += new PrintPageEventHandler(PrintDocument_PrintPage);

                PrintPreviewDialog printPreviewDialog = new PrintPreviewDialog();
                printPreviewDialog.Document = printDocument;

                if (printPreviewDialog.ShowDialog() == DialogResult.OK)
                {
                    printDocument.Print();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while printing: " + ex.Message, "Print Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            try
            {
                Font titleFont = new Font("Arial", 14, FontStyle.Bold);
                Font regularFont = new Font("Arial", 12);
                Font boldFont = new Font("Arial", 12, FontStyle.Bold);
                Font italicFont = new Font("Arial", 10, FontStyle.Italic);

                float yPos = 50;
                int leftMargin = 50;

                e.Graphics.DrawString("ABC BANK ATM RECEIPT", titleFont, Brushes.Black, leftMargin, yPos); yPos += 30;
                e.Graphics.DrawString("DATE/TIME: " + transactionDate.ToString("yyyy-MM-dd HH:mm:ss"), regularFont, Brushes.Black, leftMargin, yPos); yPos += 25;
                e.Graphics.DrawString("TRANSACTION: " + transactionType, regularFont, Brushes.Black, leftMargin, yPos); yPos += 25;
                e.Graphics.DrawString("AMOUNT: $" + amount.ToString("N2"), boldFont, Brushes.Black, leftMargin, yPos); yPos += 25;
                string maskedAccount = "XXXX" + accountNumber.Substring(Math.Max(0, accountNumber.Length - 4));
                e.Graphics.DrawString("ACCOUNT: " + maskedAccount, regularFont, Brushes.Black, leftMargin, yPos); yPos += 25;
                e.Graphics.DrawString("PREVIOUS BALANCE: $" + previousBalance.ToString("N2"), regularFont, Brushes.Black, leftMargin, yPos); yPos += 25;
                e.Graphics.DrawString("NEW BALANCE: $" + newBalance.ToString("N2"), boldFont, Brushes.Black, leftMargin, yPos); yPos += 25;
                e.Graphics.DrawString("TRANSACTION ID: " + transactionId.ToString(), regularFont, Brushes.Black, leftMargin, yPos); yPos += 40;
                e.Graphics.DrawString("Thank you for using our ATM", italicFont, Brushes.Black, leftMargin, yPos);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred during print rendering: " + ex.Message, "Print Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Transaction completed successfully. Thank you for using our ATM system.",
                "Transaction Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.Hide();
            MainMenuForm mainMenu = new MainMenuForm(accountNumber);
            mainMenu.ShowDialog();
            this.Close();
        }
    }
}

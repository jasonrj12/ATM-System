﻿using System;
using System.Windows.Forms;

namespace ATMSystem
{
    public partial class WithdrawForm : Form
    {
        private string cardNumber;
        private string accountNumber;
        private decimal[] withdrawOptions = { 20, 50, 100, 200, 500, 1000 };
        private decimal selectedAmount = 0;

        public WithdrawForm(string cardNumber, string accountNumber)
        {
            InitializeComponent();
            this.cardNumber = cardNumber;
            this.accountNumber = accountNumber;
        }

        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblPrompt = new Label();
            btn20 = new Button();
            btn50 = new Button();
            btn100 = new Button();
            btn200 = new Button();
            btn500 = new Button();
            btn1000 = new Button();
            btnOther = new Button();
            btnCancel = new Button();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblTitle.Location = new Point(150, 20);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(185, 37);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "ATM SYSTEM";
            // 
            // lblPrompt
            // 
            lblPrompt.AutoSize = true;
            lblPrompt.Font = new Font("Segoe UI", 12F);
            lblPrompt.Location = new Point(100, 70);
            lblPrompt.Name = "lblPrompt";
            lblPrompt.Size = new Size(297, 28);
            lblPrompt.TabIndex = 1;
            lblPrompt.Text = "Please select withdrawal amount:";
            // 
            // btn20
            // 
            btn20.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn20.Location = new Point(50, 120);
            btn20.Name = "btn20";
            btn20.Size = new Size(180, 50);
            btn20.TabIndex = 2;
            btn20.Text = "$20";
            btn20.UseVisualStyleBackColor = true;
            btn20.Click += btnAmount_Click;
            // 
            // btn50
            // 
            btn50.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn50.Location = new Point(230, 120);
            btn50.Name = "btn50";
            btn50.Size = new Size(180, 50);
            btn50.TabIndex = 3;
            btn50.Text = "$50";
            btn50.UseVisualStyleBackColor = true;
            btn50.Click += btnAmount_Click;
            // 
            // btn100
            // 
            btn100.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn100.Location = new Point(50, 180);
            btn100.Name = "btn100";
            btn100.Size = new Size(180, 50);
            btn100.TabIndex = 4;
            btn100.Text = "$100";
            btn100.UseVisualStyleBackColor = true;
            btn100.Click += btnAmount_Click;
            // 
            // btn200
            // 
            btn200.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn200.Location = new Point(230, 180);
            btn200.Name = "btn200";
            btn200.Size = new Size(180, 50);
            btn200.TabIndex = 5;
            btn200.Text = "$200";
            btn200.UseVisualStyleBackColor = true;
            btn200.Click += btnAmount_Click;
            // 
            // btn500
            // 
            btn500.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn500.Location = new Point(50, 240);
            btn500.Name = "btn500";
            btn500.Size = new Size(180, 50);
            btn500.TabIndex = 6;
            btn500.Text = "$500";
            btn500.UseVisualStyleBackColor = true;
            btn500.Click += btnAmount_Click;
            // 
            // btn1000
            // 
            btn1000.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn1000.Location = new Point(230, 240);
            btn1000.Name = "btn1000";
            btn1000.Size = new Size(180, 50);
            btn1000.TabIndex = 7;
            btn1000.Text = "$1000";
            btn1000.UseVisualStyleBackColor = true;
            btn1000.Click += btnAmount_Click;
            // 
            // btnOther
            // 
            btnOther.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnOther.Location = new Point(50, 300);
            btnOther.Name = "btnOther";
            btnOther.Size = new Size(180, 50);
            btnOther.TabIndex = 8;
            btnOther.Text = "Other Amount";
            btnOther.UseVisualStyleBackColor = true;
            btnOther.Click += btnOther_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.Red;
            btnCancel.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(230, 300);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(180, 50);
            btnCancel.TabIndex = 9;
            btnCancel.Text = "CANCEL";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // WithdrawForm
            // 
            ClientSize = new Size(460, 380);
            Controls.Add(lblTitle);
            Controls.Add(lblPrompt);
            Controls.Add(btn20);
            Controls.Add(btn50);
            Controls.Add(btn100);
            Controls.Add(btn200);
            Controls.Add(btn500);
            Controls.Add(btn1000);
            Controls.Add(btnOther);
            Controls.Add(btnCancel);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "WithdrawForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ATM System - Cash Withdrawal";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblPrompt;
        private System.Windows.Forms.Button btn20;
        private System.Windows.Forms.Button btn50;
        private System.Windows.Forms.Button btn100;
        private System.Windows.Forms.Button btn200;
        private System.Windows.Forms.Button btn500;
        private System.Windows.Forms.Button btn1000;
        private System.Windows.Forms.Button btnOther;
        private System.Windows.Forms.Button btnCancel;

        private void btnAmount_Click(object sender, EventArgs e)
        {
            try
            {
                Button btn = (Button)sender;
                string amountText = btn.Text.Replace("$", "");
                selectedAmount = decimal.Parse(amountText);

                ProcessWithdrawal();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnOther_Click(object sender, EventArgs e)
        {
            try
            {
                string input = InputBox.Show(
                    "Enter withdrawal amount:",
                    "Custom Amount",
                    "0");

                if (string.IsNullOrWhiteSpace(input))
                    return;

                if (decimal.TryParse(input, out decimal amount))
                {
                    if (amount <= 0)
                    {
                        MessageBox.Show("Please enter a valid amount greater than zero.", "Invalid Amount", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (amount % 10 != 0)
                    {
                        MessageBox.Show("Please enter an amount in multiples of 10.", "Invalid Amount", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    selectedAmount = amount;
                    ProcessWithdrawal();
                }
                else
                {
                    MessageBox.Show("Please enter a valid numeric amount.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ProcessWithdrawal()
        {
            try
            {
                // Get current balance
                decimal balance = DatabaseConnection.GetBalance(accountNumber);

                // Check if sufficient funds
                if (balance < selectedAmount)
                {
                    MessageBox.Show("Insufficient funds. Your current balance is $" + balance.ToString("N2"),
                        "Transaction Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Update balance
                decimal newBalance = balance - selectedAmount;
                bool updateSuccess = DatabaseConnection.UpdateBalance(accountNumber, newBalance);

                if (!updateSuccess)
                {
                    MessageBox.Show("Failed to process withdrawal. Please try again later.",
                        "Transaction Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Record transaction
                int transactionId = DatabaseConnection.RecordTransaction(accountNumber, "Withdrawal", selectedAmount);

                if (transactionId <= 0)
                {
                    MessageBox.Show("Transaction recorded but failed to generate receipt. Your withdrawal was processed successfully.",
                        "Receipt Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    ReturnToMainMenu();
                    return;
                }

                // Show receipt
                this.Hide();
                ReceiptForm receiptForm = new ReceiptForm(accountNumber, "Withdrawal", selectedAmount, balance, newBalance, transactionId);
                receiptForm.ShowDialog();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ReturnToMainMenu();
        }

        private void ReturnToMainMenu()
        {
            this.Hide();
            MainMenuForm mainMenu = new MainMenuForm(cardNumber);
            mainMenu.ShowDialog();
            this.Close();
        }
    }
}
﻿using System;
using System.Windows.Forms;

namespace ATMSystem
{
    public partial class MainMenuForm : Form
    {
        private string cardNumber;
        private string accountNumber;

        public MainMenuForm(string cardNumber)
        {
            InitializeComponent();
            this.cardNumber = cardNumber;
            this.accountNumber = "123456789"; // Later fetch dynamically if needed
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            this.Hide();
            WithdrawForm withdrawForm = new WithdrawForm(cardNumber, accountNumber);
            withdrawForm.ShowDialog();
            this.Close();
        }

        private void btnBalance_Click(object sender, EventArgs e)
        {
            decimal balance = DatabaseConnection.GetBalance(accountNumber);
            MessageBox.Show($"Your current balance is ${balance:N2}", "Balance", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnDeposit_Click(object sender, EventArgs e)
        {
            this.Hide();
            DepositForm depositForm = new DepositForm(cardNumber, accountNumber);
            depositForm.ShowDialog();
            this.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Hide();
            ATMSystem.Forms.LogoutForm logout = new ATMSystem.Forms.LogoutForm();
            logout.ShowDialog();
        }

    }
}

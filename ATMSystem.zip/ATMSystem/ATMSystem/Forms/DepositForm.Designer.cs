﻿using System;
using System.Windows.Forms;

namespace ATMSystem
{
    public partial class DepositForm : Form
    {
        private Label lblTitle;
        private Label lblPrompt;
        private TextBox txtAmount;
        private Button btnSubmit;
        private Button btnCancel;

        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblPrompt = new Label();
            txtAmount = new TextBox();
            btnSubmit = new Button();
            btnCancel = new Button();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblTitle.Location = new Point(104, 23);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(185, 37);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "ATM SYSTEM";
            // 
            // lblPrompt
            // 
            lblPrompt.AutoSize = true;
            lblPrompt.Font = new Font("Segoe UI", 12F);
            lblPrompt.Location = new Point(70, 69);
            lblPrompt.Name = "lblPrompt";
            lblPrompt.Size = new Size(205, 28);
            lblPrompt.TabIndex = 1;
            lblPrompt.Text = "Enter deposit amount:";
            // 
            // txtAmount
            // 
            txtAmount.Font = new Font("Segoe UI", 14F);
            txtAmount.Location = new Point(70, 100);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(250, 39);
            txtAmount.TabIndex = 2;
            // 
            // btnSubmit
            // 
            btnSubmit.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnSubmit.Location = new Point(70, 160);
            btnSubmit.Name = "btnSubmit";
            btnSubmit.Size = new Size(106, 40);
            btnSubmit.TabIndex = 3;
            btnSubmit.Text = "Deposit";
            btnSubmit.Click += btnSubmit_Click;
            // 
            // btnCancel
            // 
            btnCancel.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btnCancel.Location = new Point(214, 160);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(101, 40);
            btnCancel.TabIndex = 4;
            btnCancel.Text = "Cancel";
            btnCancel.Click += btnCancel_Click;
            // 
            // DepositForm
            // 
            ClientSize = new Size(400, 250);
            Controls.Add(lblTitle);
            Controls.Add(lblPrompt);
            Controls.Add(txtAmount);
            Controls.Add(btnSubmit);
            Controls.Add(btnCancel);
            Name = "DepositForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ATM System - Deposit";
            ResumeLayout(false);
            PerformLayout();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (!decimal.TryParse(txtAmount.Text, out decimal depositAmount) || depositAmount <= 0)
                {
                    MessageBox.Show("Please enter a valid positive amount.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                decimal currentBalance = DatabaseConnection.GetBalance(accountNumber);
                decimal newBalance = currentBalance + depositAmount;

                bool updated = DatabaseConnection.UpdateBalance(accountNumber, newBalance);
                if (!updated)
                {
                    MessageBox.Show("Deposit failed. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int transactionId = DatabaseConnection.RecordTransaction(accountNumber, "Deposit", depositAmount);

                MessageBox.Show("Deposit successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Hide();
                ReceiptForm receipt = new ReceiptForm(accountNumber, "Deposit", depositAmount, currentBalance, newBalance, transactionId);
                receipt.ShowDialog();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainMenuForm mainMenu = new MainMenuForm(cardNumber);
            mainMenu.ShowDialog();
            this.Close();
        }
    }
}

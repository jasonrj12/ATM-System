﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;

namespace ATMSystem
{
    public class DatabaseConnection
    {
        private static string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\ATMDatabase.mdf;Integrated Security=True";

        public static SqlConnection GetConnection()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }

        // Verify PIN with database
        public static bool VerifyPIN(string cardNumber, string pin)
        {
            bool isValid = false;

            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    string query = "SELECT COUNT(1) FROM Users WHERE CardNumber=@CardNumber AND PIN=@PIN";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@CardNumber", cardNumber);
                        command.Parameters.AddWithValue("@PIN", pin);

                        int count = (int)command.ExecuteScalar();
                        isValid = (count > 0);
                    }
                }
            }
            catch (Exception ex)
            {
                // Log exception
                Console.WriteLine("Error verifying PIN: " + ex.Message);
            }

            return isValid;
        }

        // Get account balance
        public static decimal GetBalance(string accountNumber)
        {
            decimal balance = 0;

            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    string query = "SELECT Balance FROM Accounts WHERE AccountNumber=@AccountNumber";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", accountNumber);
                        object result = command.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            balance = Convert.ToDecimal(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log exception
                Console.WriteLine("Error getting balance: " + ex.Message);
            }

            return balance;
        }

        // Update account balance after withdrawal
        public static bool UpdateBalance(string accountNumber, decimal newBalance)
        {
            bool success = false;

            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    string query = "UPDATE Accounts SET Balance=@Balance WHERE AccountNumber=@AccountNumber";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", accountNumber);
                        command.Parameters.AddWithValue("@Balance", newBalance);

                        int rowsAffected = command.ExecuteNonQuery();
                        success = (rowsAffected > 0);
                    }
                }
            }
            catch (Exception ex)
            {
                // Log exception
                Console.WriteLine("Error updating balance: " + ex.Message);
            }

            return success;
        }

        // Record transaction
        public static int RecordTransaction(string accountNumber, string transactionType, decimal amount)
        {
            int transactionId = -1;

            try
            {
                using (SqlConnection connection = GetConnection())
                {
                    connection.Open();
                    string query = @"INSERT INTO Transactions (AccountNumber, TransactionType, Amount, TransactionDate) 
                                    VALUES (@AccountNumber, @TransactionType, @Amount, @TransactionDate);
                                    SELECT SCOPE_IDENTITY();";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@AccountNumber", accountNumber);
                        command.Parameters.AddWithValue("@TransactionType", transactionType);
                        command.Parameters.AddWithValue("@Amount", amount);
                        command.Parameters.AddWithValue("@TransactionDate", DateTime.Now);

                        object result = command.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            transactionId = Convert.ToInt32(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Log exception
                Console.WriteLine("Error recording transaction: " + ex.Message);
            }

            return transactionId;
        }
    }
}
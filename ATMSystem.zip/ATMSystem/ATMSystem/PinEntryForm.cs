using System;
using System.Windows.Forms;

namespace ATMSystem
{
    public partial class PinEntryForm : Form
    {
        public PinEntryForm()
        {
            InitializeComponent();
        }
    }
}

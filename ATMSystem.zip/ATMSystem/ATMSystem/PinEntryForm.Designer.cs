﻿using System;
using System.Windows.Forms;

namespace ATMSystem
{
    public partial class PinEntryForm : Form
    {
        private string cardNumber = "1234567890123456"; // Default for testing
        private string enteredPin = "";



        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblPinPrompt = new Label();
            txtPin = new TextBox();
            btnEnter = new Button();
            btnClear = new Button();
            btnCancel = new Button();
            btn1 = new Button();
            btn2 = new Button();
            btn3 = new Button();
            btn4 = new Button();
            btn5 = new Button();
            btn6 = new Button();
            btn7 = new Button();
            btn8 = new Button();
            btn9 = new Button();
            btn0 = new Button();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblTitle.Location = new Point(105, 20);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(185, 37);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "ATM SYSTEM";
            // 
            // lblPinPrompt
            // 
            lblPinPrompt.AutoSize = true;
            lblPinPrompt.Font = new Font("Segoe UI", 12F);
            lblPinPrompt.Location = new Point(105, 70);
            lblPinPrompt.Name = "lblPinPrompt";
            lblPinPrompt.Size = new Size(156, 28);
            lblPinPrompt.TabIndex = 1;
            lblPinPrompt.Text = "Please Enter PIN:";
            // 
            // txtPin
            // 
            txtPin.Font = new Font("Segoe UI", 14F);
            txtPin.Location = new Point(105, 100);
            txtPin.Name = "txtPin";
            txtPin.PasswordChar = '*';
            txtPin.ReadOnly = true;
            txtPin.Size = new Size(150, 39);
            txtPin.TabIndex = 2;
            txtPin.TextAlign = HorizontalAlignment.Center;
            // 
            // btnEnter
            // 
            btnEnter.BackColor = Color.Green;
            btnEnter.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnEnter.ForeColor = Color.White;
            btnEnter.Location = new Point(285, 150);
            btnEnter.Name = "btnEnter";
            btnEnter.Size = new Size(80, 50);
            btnEnter.TabIndex = 13;
            btnEnter.Text = "ENTER";
            btnEnter.UseVisualStyleBackColor = false;
            btnEnter.Click += btnEnter_Click;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.Yellow;
            btnClear.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnClear.Location = new Point(285, 210);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(80, 50);
            btnClear.TabIndex = 14;
            btnClear.Text = "CLEAR";
            btnClear.UseVisualStyleBackColor = false;
            btnClear.Click += btnClear_Click;
            // 
            // btnCancel
            // 
            btnCancel.BackColor = Color.Red;
            btnCancel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnCancel.ForeColor = Color.White;
            btnCancel.Location = new Point(285, 270);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(80, 50);
            btnCancel.TabIndex = 15;
            btnCancel.Text = "CANCEL";
            btnCancel.UseVisualStyleBackColor = false;
            btnCancel.Click += btnCancel_Click;
            // 
            // btn1
            // 
            btn1.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn1.Location = new Point(75, 150);
            btn1.Name = "btn1";
            btn1.Size = new Size(60, 50);
            btn1.TabIndex = 3;
            btn1.Text = "1";
            btn1.UseVisualStyleBackColor = true;
            btn1.Click += NumericButton_Click;
            // 
            // btn2
            // 
            btn2.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn2.Location = new Point(145, 150);
            btn2.Name = "btn2";
            btn2.Size = new Size(60, 50);
            btn2.TabIndex = 4;
            btn2.Text = "2";
            btn2.UseVisualStyleBackColor = true;
            btn2.Click += NumericButton_Click;
            // 
            // btn3
            // 
            btn3.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn3.Location = new Point(215, 150);
            btn3.Name = "btn3";
            btn3.Size = new Size(60, 50);
            btn3.TabIndex = 5;
            btn3.Text = "3";
            btn3.UseVisualStyleBackColor = true;
            btn3.Click += NumericButton_Click;
            // 
            // btn4
            // 
            btn4.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn4.Location = new Point(75, 210);
            btn4.Name = "btn4";
            btn4.Size = new Size(60, 50);
            btn4.TabIndex = 6;
            btn4.Text = "4";
            btn4.UseVisualStyleBackColor = true;
            btn4.Click += NumericButton_Click;
            // 
            // btn5
            // 
            btn5.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn5.Location = new Point(145, 210);
            btn5.Name = "btn5";
            btn5.Size = new Size(60, 50);
            btn5.TabIndex = 7;
            btn5.Text = "5";
            btn5.UseVisualStyleBackColor = true;
            btn5.Click += NumericButton_Click;
            // 
            // btn6
            // 
            btn6.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn6.Location = new Point(215, 210);
            btn6.Name = "btn6";
            btn6.Size = new Size(60, 50);
            btn6.TabIndex = 8;
            btn6.Text = "6";
            btn6.UseVisualStyleBackColor = true;
            btn6.Click += NumericButton_Click;
            // 
            // btn7
            // 
            btn7.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn7.Location = new Point(75, 270);
            btn7.Name = "btn7";
            btn7.Size = new Size(60, 50);
            btn7.TabIndex = 9;
            btn7.Text = "7";
            btn7.UseVisualStyleBackColor = true;
            btn7.Click += NumericButton_Click;
            // 
            // btn8
            // 
            btn8.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn8.Location = new Point(145, 270);
            btn8.Name = "btn8";
            btn8.Size = new Size(60, 50);
            btn8.TabIndex = 10;
            btn8.Text = "8";
            btn8.UseVisualStyleBackColor = true;
            btn8.Click += NumericButton_Click;
            // 
            // btn9
            // 
            btn9.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn9.Location = new Point(215, 270);
            btn9.Name = "btn9";
            btn9.Size = new Size(60, 50);
            btn9.TabIndex = 11;
            btn9.Text = "9";
            btn9.UseVisualStyleBackColor = true;
            btn9.Click += NumericButton_Click;
            // 
            // btn0
            // 
            btn0.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            btn0.Location = new Point(145, 330);
            btn0.Name = "btn0";
            btn0.Size = new Size(60, 50);
            btn0.TabIndex = 12;
            btn0.Text = "0";
            btn0.UseVisualStyleBackColor = true;
            btn0.Click += NumericButton_Click;
            // 
            // PinEntryForm
            // 
            ClientSize = new Size(440, 400);
            Controls.Add(lblTitle);
            Controls.Add(lblPinPrompt);
            Controls.Add(txtPin);
            Controls.Add(btn1);
            Controls.Add(btn2);
            Controls.Add(btn3);
            Controls.Add(btn4);
            Controls.Add(btn5);
            Controls.Add(btn6);
            Controls.Add(btn7);
            Controls.Add(btn8);
            Controls.Add(btn9);
            Controls.Add(btn0);
            Controls.Add(btnEnter);
            Controls.Add(btnClear);
            Controls.Add(btnCancel);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            Name = "PinEntryForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ATM System - PIN Entry";
            ResumeLayout(false);
            PerformLayout();
        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblPinPrompt;
        private System.Windows.Forms.TextBox txtPin;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn0;

        private void NumericButton_Click(object sender, EventArgs e)
        {
            if (enteredPin.Length < 4)
            {
                Button btn = (Button)sender;
                enteredPin += btn.Text;
                txtPin.Text = new string('*', enteredPin.Length);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            enteredPin = "";
            txtPin.Text = "";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            try
            {
                // Validation
                if (enteredPin.Length < 4)
                {
                    MessageBox.Show("Please enter a 4-digit PIN.", "Invalid PIN", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Verify PIN with database
                bool isValid = DatabaseConnection.VerifyPIN(cardNumber, enteredPin);

                if (isValid)
                {
                    // PIN correct, open main menu
                    this.Hide();
                    MainMenuForm mainMenu = new MainMenuForm(cardNumber);
                    mainMenu.ShowDialog();
                    this.Close();
                }
                else
                {
                    // PIN incorrect
                    MessageBox.Show("Invalid PIN. Please try again.", "Authentication Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    btnClear_Click(sender, e);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
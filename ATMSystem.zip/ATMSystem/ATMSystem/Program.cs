using System;
using System.Windows.Forms;

namespace ATMSystem
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Create database if it doesn't exist
            try
            {
                DatabaseSetup.CreateDatabaseIfNotExists();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error setting up database: " + ex.Message,
                    "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.Run(new ATMSystem.Forms.WelcomeForm());

        }
    }
}
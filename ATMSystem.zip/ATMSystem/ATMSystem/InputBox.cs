﻿using System;
using System.Windows.Forms;

namespace ATMSystem
{
    public static class InputBox
    {
        public static string Show(string prompt, string title, string defaultValue = "")
        {
            Form inputForm = new Form()
            {
                Width = 400,
                Height = 200,
                Text = title,
                StartPosition = FormStartPosition.CenterScreen,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                MaximizeBox = false,
                MinimizeBox = false
            };

            Label promptLabel = new Label()
            {
                Text = prompt,
                Left = 20,
                Top = 20,
                Width = 360
            };
            inputForm.Controls.Add(promptLabel);

            TextBox textBox = new TextBox()
            {
                Left = 20,
                Top = 50,
                Width = 360,
                Text = defaultValue
            };
            inputForm.Controls.Add(textBox);

            Button okButton = new Button()
            {
                Text = "OK",
                Left = 200,
                Top = 100,
                DialogResult = DialogResult.OK
            };
            inputForm.Controls.Add(okButton);

            Button cancelButton = new Button()
            {
                Text = "Cancel",
                Left = 280,
                Top = 100,
                DialogResult = DialogResult.Cancel
            };
            inputForm.Controls.Add(cancelButton);

            inputForm.AcceptButton = okButton;
            inputForm.CancelButton = cancelButton;

            return inputForm.ShowDialog() == DialogResult.OK ? textBox.Text : "";
        }
    }
}
﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.IO;

namespace ATMSystem
{
    public class DatabaseSetup
    {
        private static string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\ATMDatabase.mdf;Integrated Security=True";

        public static void CreateDatabaseIfNotExists()
        {
            string dbFolderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Data");
            string dbFilePath = Path.Combine(dbFolderPath, "ATMDatabase.mdf");

            // Set the DataDirectory
            AppDomain.CurrentDomain.SetData("DataDirectory", dbFolderPath);

            // Create directory if it doesn't exist
            if (!Directory.Exists(dbFolderPath))
            {
                Directory.CreateDirectory(dbFolderPath);
            }

            // Check if database file exists
            if (!File.Exists(dbFilePath))
            {
                // Database doesn't exist, create it
                string connectionStringCreate = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True";

                using (SqlConnection connection = new SqlConnection(connectionStringCreate))
                {
                    connection.Open();

                    // Create database
                    string createDbQuery = string.Format(
                        "CREATE DATABASE ATMDatabase ON PRIMARY " +
                        "(NAME = ATMDatabase_Data, FILENAME = '{0}', SIZE = 5MB, MAXSIZE = 10MB, FILEGROWTH = 10%) " +
                        "LOG ON (NAME = ATMDatabase_Log, FILENAME = '{1}', SIZE = 1MB, MAXSIZE = 5MB, FILEGROWTH = 10%)",
                        dbFilePath, Path.Combine(dbFolderPath, "ATMDatabase_Log.ldf"));

                    using (SqlCommand command = new SqlCommand(createDbQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }

                // Create tables
                CreateTables();

                // Insert test data
                InsertTestData();
            }
        }

        private static void CreateTables()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Create Users table
                string createUsersTable = @"
                    CREATE TABLE Users (
                        UserId INT PRIMARY KEY IDENTITY(1,1),
                        CardNumber VARCHAR(16) NOT NULL UNIQUE,
                        PIN VARCHAR(4) NOT NULL,
                        FirstName NVARCHAR(50) NOT NULL,
                        LastName NVARCHAR(50) NOT NULL,
                        Email NVARCHAR(100),
                        Phone NVARCHAR(20),
                        CreatedAt DATETIME DEFAULT GETDATE()
                    )";

                using (SqlCommand command = new SqlCommand(createUsersTable, connection))
                {
                    command.ExecuteNonQuery();
                }

                // Create Accounts table
                string createAccountsTable = @"
                    CREATE TABLE Accounts (
                        AccountId INT PRIMARY KEY IDENTITY(1,1),
                        UserId INT NOT NULL,
                        AccountNumber VARCHAR(20) NOT NULL UNIQUE,
                        AccountType NVARCHAR(20) NOT NULL,
                        Balance DECIMAL(18, 2) NOT NULL DEFAULT 0,
                        CreatedAt DATETIME DEFAULT GETDATE(),
                        FOREIGN KEY (UserId) REFERENCES Users(UserId)
                    )";

                using (SqlCommand command = new SqlCommand(createAccountsTable, connection))
                {
                    command.ExecuteNonQuery();
                }

                // Create Transactions table
                string createTransactionsTable = @"
                    CREATE TABLE Transactions (
                        TransactionId INT PRIMARY KEY IDENTITY(1,1),
                        AccountNumber VARCHAR(20) NOT NULL,
                        TransactionType NVARCHAR(20) NOT NULL,
                        Amount DECIMAL(18, 2) NOT NULL,
                        TransactionDate DATETIME NOT NULL DEFAULT GETDATE()
                    )";

                using (SqlCommand command = new SqlCommand(createTransactionsTable, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        private static void InsertTestData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Insert test user
                string insertUser = @"
                    INSERT INTO Users (CardNumber, PIN, FirstName, LastName, Email, Phone)
                    VALUES ('1234567890123456', '1234', 'John', 'Doe', 'john.doe@example.com', '+1234567890')";

                int userId = 0;

                using (SqlCommand command = new SqlCommand(insertUser, connection))
                {
                    command.ExecuteNonQuery();

                    // Get the inserted user ID
                    command.CommandText = "SELECT @@IDENTITY";
                    userId = Convert.ToInt32(command.ExecuteScalar());
                }

                // Insert test account
                string insertAccount = @"
                    INSERT INTO Accounts (UserId, AccountNumber, AccountType, Balance)
                    VALUES (@UserId, '123456789', 'Savings', 5000.00)";

                using (SqlCommand command = new SqlCommand(insertAccount, connection))
                {
                    command.Parameters.AddWithValue("@UserId", userId);
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}